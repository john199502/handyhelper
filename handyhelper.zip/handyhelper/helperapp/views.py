from django.shortcuts import render, redirect
from django.contrib import messages
import bcrypt
from .models import User, Job

def index(request):
    return render(request, "index.html")
def register(request):
    errors = User.objects.basic_validator(request.POST)

    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect("/")
    else:
        hash1 = bcrypt.hashpw(request.POST['password'].encode(), bcrypt.gensalt()).decode()
        u = User.objects.create(lastname=request.POST['lastname'], firstname=request.POST['firstname'], email=request.POST['email'], password=hash1)
        request.session['userid'] = u.id
        return redirect("/userdashboard")

def login(request):
    user = User.objects.filter(email=request.POST['email'])
    errors = {}
    if not user:
        errors['email'] = "Invalid email or password"
    else:
        logged_user = user[0]
        if bcrypt.checkpw(request.POST['password'].encode(), logged_user.password.encode()):
            request.session['userid'] = logged_user.id
            return redirect("/userdashboard")
        else:
            errors['password'] = "Invalid email or password"
    
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect("/")
    else:
        return redirect("//userdashboard")

def dashboard(request):
    if 'userid' not in request.session:
        return redirect("/")
    else:
        context = {
            "loggedin": User.objects.get(id=request.session['userid']),
            "userjobs": Job.objects.filter(users=User.objects.get(id=request.session['userid'])),
            "alljobs": Job.objects.all()
        }
        return render(request, "dash.html", context)

def addjob(request, id):
    if 'userid' not in request.session:
        return redirect("/")
    
    return render(request, "newjob.html")

def createjob(request):
    errors = Job.objects.basic_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect("/add_job") 
    else:
        Job.objects.create(title=request.POST['title'],location=request.POST['location'],description=request.POST['description'])
        return redirect("/userdashboard")

def info(request, id):
    if 'userid' not in request.session:
        return redirect("/")
    context = {
        "jobinfo": Job.objects.get(id=id),
        "loggedin": User.objects.get(id=request.session['userid'])
    }
    return render(request, "info.html", context)

def edit(request, id):
    if 'userid' not in request.session:
        return redirect("/")
    context = {
        "job": Job.objects.get(id=id)
    }
    return render(request, "edit.html", context)
def updatejob(request, id):
    job = Job.objects.get(id=id)
    job.title = request.POST['title']
    job.description = request.POST['description']
    job.location = request.POST['location']
    job.save()
    return redirect("/userdashboard")
def cancel(request):
    if 'userid' not in request.session:
        return redirect("/")
    return redirect("/userdashboard")
def addwork(request, id):
    if 'userid' not in request.session:
        return redirect("/")
    loggedin = User.objects.get(id=request.session['userid'])
    job = Job.objects.get(id=id)
    job.worker.add(loggedin)
    return redirect("/userdashboard")

def logout(request):
    request.session.clear()
    return redirect("/")
