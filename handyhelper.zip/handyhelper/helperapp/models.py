from __future__ import unicode_literals
import re
from django.db import models
#login registration validator
class UserManager(models.Manager):
    def basic_validator(self, postData):
        errors = {}
        #name validations
        if len(postData['firstname']) < 1:
            errors['firstname'] = "Name must be at least 1 characters!"
        if len(postData['lastname']) < 1:
            errors['lastname'] = "Name must be at least 1 characters!"

        #Email validation
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        if not EMAIL_REGEX.match(postData['email']):           
            errors['email'] = "Invalid email address!"
        
        all_users = User.objects.all()
        for x in all_users:
            if x.email == postData['email']:
                errors['email'] = "Email must be unique!"
        # Password Validations
        if len(postData['password']) < 8:
            errors['password'] = "Password must be at least 8 characters!"
        
        if postData['password'] != postData['cpassword']:
            errors['password'] = "Password does not match password confirm!"
        return errors
# Job creation Validator
class JobManager(models.Manager):
    def basic_validator(self, postData):
        errors = {}
        if len(postData['title']) < 3:
            errors['title'] = "Title must be at least 3 or more characters!"
        if len(postData['location']) < 1:
            errors['location'] = "Location required"
        if len(postData['description']) < 10:
            errors['description'] = "description must be at least 10 or more characters!"
        return errors
# user
class User(models.Model):
    firstname = models.CharField(max_length=45)
    lastname = models.CharField(max_length=45)
    email = models.CharField(max_length=255)
    password = models.CharField(max_length=255, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = UserManager()
#Job information 
class Job(models.Model):
    title = models.CharField(max_length=45)
    description = models.CharField(max_length=255)
    location = models.CharField(max_length=45)
    users = models.ForeignKey(User, related_name="userjobs", on_delete=models.CASCADE, null = True)
    worker = models.ManyToManyField(User, related_name="jobhelp")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = JobManager()