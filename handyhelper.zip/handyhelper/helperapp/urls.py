from django.urls import path
from . import views

urlpatterns = [
    path('', views.index),
    path('login', views.login),
    path('register', views.register),
    path('userdashboard', views.dashboard),
    path('add_job', views.addjob),
    path('job/create', views.createjob),
    path('view/<int:id>', views.info),
    path('edit/<int:id>', views.edit),
    path('job/update/<int:id>', views.updatejob),
    path('cancel/<int:id>', views.cancel),
    path('add/<int:id>', views.addwork),
    path('logout', views.logout),
]