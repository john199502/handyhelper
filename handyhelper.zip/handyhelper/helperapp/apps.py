from django.apps import AppConfig


class HelperappConfig(AppConfig):
    name = 'helperapp'
